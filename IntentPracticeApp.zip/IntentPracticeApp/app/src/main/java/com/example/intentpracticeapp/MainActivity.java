package com.example.intentpracticeapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tvInfo = findViewById(R.id.tvInfo);

        Button btnSendEmail = findViewById(R.id.btnSendEmail);
        btnSendEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse("mailto:ccaulanday@bpsu.edu.ph"));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "My App Feedback");
                emailIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hello, here’s my feedback about the app...");
                startActivity(emailIntent);
                tvInfo.setText("Send Email with");
            }
        });

        Button btnOpenMap = findViewById(R.id.btnOpenMap);
        btnOpenMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri location = Uri.parse("geo:0,0?q=Mariveles+Bataan");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);

                startActivity(Intent.createChooser(mapIntent, "Open map with"));
                tvInfo.setText("Open map with");
            }
        });

        Button btnShare = findViewById(R.id.btnShare);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out my new Android app!");
                startActivity(Intent.createChooser(shareIntent, "Share via"));
                tvInfo.setText("SharezX  with");
            }
        });
    }
}