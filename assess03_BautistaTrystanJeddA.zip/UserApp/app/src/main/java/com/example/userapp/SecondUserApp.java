package com.example.userapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class SecondUserApp extends AppCompatActivity {

    TextView tvName, tvAge;
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_user_app);

        tvName = findViewById(R.id.tvName);
        tvAge = findViewById(R.id.tvAge);
        btnBack = findViewById(R.id.btnBACK);

        String name = getIntent().getStringExtra("name");
        String gender = getIntent().getStringExtra("gender");
        int y = getIntent().getIntExtra("year", -1);
        int m = getIntent().getIntExtra("month", -1);
        int d = getIntent().getIntExtra("day", -1);

        if (name == null) name = "";
        if (gender == null) gender = "";

        if (gender.equalsIgnoreCase("female")) {
            tvName.setText("Hi Ms. " + name);
        } else if (gender.equalsIgnoreCase("male")) {
            tvName.setText("Hi Mr. " + name);
        } else {
            tvName.setText("Hi " + name);
        }

        if (y > 0 && m > 0 && d > 0) {
            Calendar today = Calendar.getInstance();
            int age = today.get(Calendar.YEAR) - y;

            if (today.get(Calendar.MONTH) + 1 < m ||
                    (today.get(Calendar.MONTH) + 1 == m && today.get(Calendar.DAY_OF_MONTH) < d)) {
                age--;
            }
            if (age < 0) age = 0;

            tvAge.setText("Your Age is: " + age);
        } else {
            tvAge.setText("Your Age is: ");
        }

        // Back button action
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go back to MainActivity
                Intent intent = new Intent(SecondUserApp.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
