package com.example.userapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText etName, etBirthdate;
    Spinner spGender;
    Button btnNext;
    int year, month, day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etBirthdate = findViewById(R.id.etBirthdate);
        spGender = findViewById(R.id.spGender);
        btnNext = findViewById(R.id.btnNext);

        etBirthdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                int y = c.get(Calendar.YEAR);
                int m = c.get(Calendar.MONTH);
                int d = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dp = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int yy, int mm, int dd) {
                        year = yy;
                        month = mm + 1;
                        day = dd;
                        etBirthdate.setText(month + "/" + day + "/" + year);
                    }
                }, y, m, d);
                dp.show();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String gender = spGender.getSelectedItem().toString();

                Intent i = new Intent(MainActivity.this, SecondUserApp.class);
                i.putExtra("name", name);
                i.putExtra("gender", gender);
                i.putExtra("year", year);
                i.putExtra("month", month);
                i.putExtra("day", day);
                startActivity(i);
            }
        });
    }
}
